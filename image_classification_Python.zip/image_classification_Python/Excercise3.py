# Exercise3.py
import cv2
import numpy as np

# Callback function for the trackbars
def update_threshold(_):
    # Read the current position of the 'Threshold' trackbar
    thresh_val = cv2.getTrackbarPos('Threshold', 'Trackbars')
    # Read the current position of the 'Max Value' trackbar
    max_val = cv2.getTrackbarPos('Max Value', 'Trackbars')

    # Apply different thresholding methods to the image using the trackbar values
    _, binary = cv2.threshold(image, thresh_val, max_val, cv2.THRESH_BINARY)
    _, binary_inv = cv2.threshold(image, thresh_val, max_val, cv2.THRESH_BINARY_INV)
    _, trunc = cv2.threshold(image, thresh_val, max_val, cv2.THRESH_TRUNC)
    _, tozero = cv2.threshold(image, thresh_val, max_val, cv2.THRESH_TOZERO)
    _, tozero_inv = cv2.threshold(image, thresh_val, max_val, cv2.THRESH_TOZERO_INV)

    # Stack the thresholded images horizontally for comparison
    h_stack = np.hstack([binary, binary_inv, trunc, tozero, tozero_inv])
    # Stack the thresholded images vertically for comparison
    v_stack = np.vstack([binary, binary_inv, trunc, tozero, tozero_inv])

    # Resize the stacked images for better visualization
    resize_factor = 0.05  # Factor to reduce image size for display
    h_stack_resized = cv2.resize(h_stack, (int(h_stack.shape[1] * resize_factor), int(h_stack.shape[0] * resize_factor)))
    v_stack_resized = cv2.resize(v_stack, (int(v_stack.shape[1] * resize_factor), int(v_stack.shape[0] * resize_factor)))

    # Display the horizontally stacked thresholded images in a window
    cv2.imshow("Horizontal Stack (Resized)", h_stack_resized)
    # Display the vertically stacked thresholded images in a window
    cv2.imshow("Vertical Stack (Resized)", v_stack_resized)

# Load the image in grayscale mode (0 means grayscale)
image = cv2.imread('piece03.png', 0)

# Create a window for trackbars to control thresholding values
cv2.namedWindow('Trackbars')
# Create the 'Threshold' trackbar with initial value 127 and max value 255
cv2.createTrackbar('Threshold', 'Trackbars', 127, 255, update_threshold)
# Create the 'Max Value' trackbar with initial value 255 and max value 255
cv2.createTrackbar('Max Value', 'Trackbars', 255, 255, update_threshold)

# Call the update_threshold function to initialize the display
update_threshold(0)

# Wait for a key event indefinitely
cv2.waitKey(0)
# Destroy all created OpenCV windows after key press
cv2.destroyAllWindows()



###########Answer####################

# -Optimal threshold value ranges for the images used-
# -lower threshold: 70
# -upper threshold: 130 , And these three objects ranges isolates in all filters effectively.

# -Since pixel values cannot be greater than 225, higher resolution is not required.
# -Eight-bit values, spanning from 0 to 255, are used in greyscale graphics.
# -There would be no extra processing or visualisation precision if the resolution were increased.

# 3. When the threshold is altered, what happens to the stacks?
# - The horizontal and vertical stacks are dynamically modified.
# - This enables the visualisation of thresholding techniques' effects on the image in real time.

#####################################

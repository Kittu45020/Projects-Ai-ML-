import cv2 as cv
import numpy as np

# Load the image in color mode
image = cv.imread("colormap.jpg")

if image is None:
    raise FileNotFoundError("Image 'colormap.jpg' not found.")

# Split the image into its BGR channels
blue_channel, green_channel, red_channel = cv.split(image)

# Create empty channels for grayscale-to-color mapping
zeros = np.zeros_like(blue_channel)

# Combine channels to create images with only one color channel
blue_image = cv.merge([blue_channel, zeros, zeros])
green_image = cv.merge([zeros, green_channel, zeros])
red_image = cv.merge([zeros, zeros, red_channel])

# Display grayscale channels
cv.imshow("Blue Channel (Grayscale)", blue_channel)
cv.imshow("Green Channel (Grayscale)", green_channel)
cv.imshow("Red Channel (Grayscale)", red_channel)

# Display color channels
cv.imshow("Blue Channel (Color)", blue_image)
cv.imshow("Green Channel (Color)", green_image)
cv.imshow("Red Channel (Color)", red_image)

cv.imshow("Original window ",image)

cv.waitKey(0)
cv.destroyAllWindows()

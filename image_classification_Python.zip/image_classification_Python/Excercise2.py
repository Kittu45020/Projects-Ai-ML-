import cv2 as cv
import sys

# Function to display the image
def img_show(img, window_name="Image"):
    cv.imshow(window_name, img)
    cv.waitKey(0)
    cv.destroyAllWindows()

# Function to extract RGB values from specific points
def get_rgb_values(img, points):
    rgb_values = {}
    for i, point in enumerate(points):
        x, y = point
        rgb = img[y, x]  # Access pixel value
        rgb_values[f"Point {i+1}"] = rgb
    return rgb_values

# Read the image in color mode
img = cv.imread("colormap.jpg")

if img is None:
    sys.exit("Could not read the image.")

# Display the image
img_show(img, "Original Image")

# Convert the image to RGB (from BGR as OpenCV uses BGR format)
img_rgb = cv.cvtColor(img, cv.COLOR_BGR2RGB)

# Specify points (x, y) to extract RGB values
points = [
    (393, 22),   #coordination for Point 1
    (226, 128),  #coordination for Point 2
    (383, 305),  #coordination for point 3
    (133, 341)   #coordination for Point 4
]

# Extract RGB values for the specified points
rgb_values = get_rgb_values(img_rgb, points)

# Print RGB values
for point, value in rgb_values.items():
    print(f"{point}: {value}")


###########Answer####################

# The values below with the output after running the code
# script initially outputs to the command window the RGB values for the specified coordinates.
# The script lets you interactively click on the image to obtain more RGB values after presenting the predefined values.

#[0, 0 , 204]  # Point 1: [R1, G1, B1]
#[0, 254, 255] # Point 2: [R2, G2, B2]
#[255 102 159] # Point 3: [R3, G3, B3]
#[152, 203, 0] # Point 4: [R4, G4, B4]

#####################################
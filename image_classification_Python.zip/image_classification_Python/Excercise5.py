import cv2
import numpy as np

# Load the image
image = cv2.imread('piece05.png')
if image is None:
    print("Error: Image not found!")
    exit()

# Resize the image to a manageable size
resize_factor = 0.1
image = cv2.resize(image, (int(image.shape[1] * resize_factor), int(image.shape[0] * resize_factor)))

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Create a window with trackbars for preprocessing adjustments
cv2.namedWindow('Adjustments')
cv2.createTrackbar('Blur', 'Adjustments', 5, 21, lambda x: None)
cv2.createTrackbar('Lower Canny', 'Adjustments', 50, 255, lambda x: None)
cv2.createTrackbar('Upper Canny', 'Adjustments', 150, 255, lambda x: None)

while True:
    # Get trackbar positions
    blur_value = cv2.getTrackbarPos('Blur', 'Adjustments')
    lower_canny = cv2.getTrackbarPos('Lower Canny', 'Adjustments')
    upper_canny = cv2.getTrackbarPos('Upper Canny', 'Adjustments')

    # Ensure blur kernel size is odd
    blur_value = max(1, blur_value | 1)  # Ensures value is at least 1 and odd

    # Apply Gaussian Blur and Canny Edge Detection
    blurred = cv2.GaussianBlur(gray, (blur_value, blur_value), 0)
    edges = cv2.Canny(blurred, lower_canny, upper_canny)

    # Find and draw contours
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contour_image = image.copy()
    cv2.drawContours(contour_image, contours, -1, (0, 255, 0), 2)

    # Display the results
    cv2.imshow('Blurred', blurred)
    cv2.imshow('Edges', edges)
    cv2.imshow('Contours', contour_image)

    # Output the number of contours detected
    print(f"Contours Found: {len(contours)}")

    # Exit on pressing 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()


###########Answer####################

# Explanation of Filters
# - Gaussian Blur: Reduces noise and smooths the image, which is crucial for stable edge detection.
#   Use it when the image has high noise levels or fine details that are not essential.
#
# - Binarization: Converts the image into a binary format, separating objects from the background.
#   This is ideal for scenarios where object edges are well-defined by intensity differences.
#
# - Canny Edge Detection: Detects strong gradients in intensity, highlighting edges of objects.
#   It is particularly useful for complex images with overlapping objects or weak edges.
#
# ### Best Circumstances for Each Filter:
# - Gaussian Blur: Best for noisy images. Adjust the kernel size based on noise level. Larger kernel = stronger smoothing.
# - Binarization: Works well when objects are clearly distinguishable in grayscale (e.g., high contrast images).
# - Canny Edge Detection: Ideal for detecting object boundaries in complex images. Tune thresholds for better accuracy.
#
# ### Image Acquisition Recommendations:
# - Ensure the image is well-lit with uniform lighting to reduce shadows and reflections.
# - Use a higher-resolution camera to capture finer details.
# - Position the object against a contrasting background to improve edge detection.
# - Minimize motion blur by stabilizing the camera and object during capture.

#####################################
import cv2

# Load the image
image = cv2.imread('star.png', cv2.IMREAD_COLOR)

if image is None:
    raise FileNotFoundError("Image not found.")
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Canny Edge Detection
edges = cv2.Canny(gray_image, 100, 200)

# Apply Binarization and invert if necessary
_, binary_image = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY_INV)

# Find contours
contours_canny, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
contours_binary, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Check for the largest contour
largest_contour_canny = max(contours_canny, key=cv2.contourArea) if contours_canny else None
largest_contour_binary = max(contours_binary, key=cv2.contourArea) if contours_binary else None

# Calculate center points for the largest contours
def calculate_center(moment):
    if moment["m00"] != 0:
        return (int(moment["m10"] / moment["m00"]), int(moment["m01"] / moment["m00"]))
    return (0, 0)

center_canny = calculate_center(cv2.moments(largest_contour_canny)) if largest_contour_canny is not None else (0, 0)
center_binary = calculate_center(cv2.moments(largest_contour_binary)) if largest_contour_binary is not None else (0, 0)

# Print the centroids
print(f"Canny center: {center_canny}")
print(f"Binarization center: {center_binary}")

# Draw the center points on copies of the original image
image_canny = image.copy()
image_binary = image.copy()

if largest_contour_canny is not None:
    cv2.circle(image_canny, center_canny, 5, (255, 0, 0), -1)  # Red for Canny
if largest_contour_binary is not None:
    cv2.circle(image_binary, center_binary, 5, (0, 255, 0), -1)  # Green for Binarization

# Display the results
cv2.imshow("Canny Center Point", image_canny)
cv2.imshow("Binarization Center Point", image_binary)
cv2.waitKey(0)
cv2.destroyAllWindows()



# ###### ANSWERS ######

# output:
# Canny center: (88, 113)
# Binarization center: (88, 113)

# Center of the object using the Canny filter:
# (cx_canny, cy_canny) = center_canny

# Center of the object using the Binarization filter:
# (cx_binary, cy_binary) = center_binary

# Observations:
# - Both methods yield similar center coordinates.
# - The Canny filter provides more precise edges but can be sensitive to noise.
# - Binarization is simpler and less prone to noise but requires a good threshold value.

#####################################


import cv2
import numpy as np

# Function to correct angle range to [-90, 90]
def correct_angle(angle):
    return angle if angle < 90 else angle - 180

# Load the image
image = cv2.imread('tree.png')

if image is None:
    print("Error: Image not found.")
    exit()

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Canny edge detection
canny_edges = cv2.Canny(gray, 100, 200)
contours_canny, _ = cv2.findContours(canny_edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Find the largest contour and its angle for Canny
largest_contour_canny = max(contours_canny, key=cv2.contourArea)
rect_canny = cv2.minAreaRect(largest_contour_canny)
angle_canny = correct_angle(rect_canny[-1])  # Get the angle and correct range

# Apply thresholding (Binarization)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
contours_binary, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Find the largest contour and its angle for Binarization
largest_contour_binary = max(contours_binary, key=cv2.contourArea)
rect_binary = cv2.minAreaRect(largest_contour_binary)
angle_binary = correct_angle(rect_binary[-1])  # Get the angle and correct range

# Draw rectangles for both methods on the original image
box_canny = cv2.boxPoints(rect_canny).astype(int)
cv2.drawContours(image, [box_canny], 0, (0, 255, 0), 2)  # Green for Canny

box_binary = cv2.boxPoints(rect_binary).astype(int)
cv2.drawContours(image, [box_binary], 0, (255, 0, 0), 2)  # Blue for Binarization

# Print the angles
print(f"Angle from the Canny - {angle_canny} degrees")
print(f"Angle from the Binarization - {angle_binary} degrees")

# Display the results
cv2.imshow("Original Image with the Rectangles", image)
cv2.imshow("Canny Edges", canny_edges)
cv2.imshow("Binarization", binary)

cv2.waitKey(0)
cv2.destroyAllWindows()

# # ###### ANSWERS ######

# Angle from the Canny - 68.6001968383789 degrees
# Angle from the Binarization - 68.86017608642578 degrees

# Angles Obtained from Each Method:
# Canny Edge Detection:
# The orientation angle calculated is 68.60 degrees (approximately).
# This angle represents the rotation of the bounding rectangle enclosing the largest contour detected by Canny edge detection.
# Thresholding (Binarization):
# The orientation angle calculated is 68.86 degrees (approximately).
# This angle is derived from the bounding rectangle enclosing the largest contour detected by binarization.

#####################################
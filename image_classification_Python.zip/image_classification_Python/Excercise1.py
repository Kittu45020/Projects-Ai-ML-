import cv2 as cv
import sys

# Function to display the image
def img_show(img, window_name="Image"):
    cv.imshow(window_name, img)
    cv.waitKey(0)
    cv.destroyAllWindows()

# List of image filenames
image_filenames = ["Original.png", "colormap.jpg",  "piece03.png", "piece05.png", "star.png", "tree.png"]

# Loop through each image and process it
for filename in image_filenames:
    print(f"\nProcessing image: {filename}")

    # Read the image in grayscale mode
    img = cv.imread(filename,cv.IMREAD_GRAYSCALE)

    if img is None:
        print(f"Could not read the image: {filename}")
        continue

    # Display the image (optional, you can comment this line if you don't want to display)
    img_show(img, window_name=filename)

    # Print image properties
    print("Data type of the image:", img.dtype)
    print("Shape (Height, Width):", img.shape)
    print("Image size (Total ..+):", img.size)
    print("Maximum pixel value:", img.max())
    print("Minimum pixel value:", img.min())
    print(f"No.of channels: {1 if len(img.shape)==2 else img.shape[2]}")


###########Answer####################

# 1.Processing image: Original.png
# Data type of the image: uint8
# Shape (Height, Width): (540, 1050)
# Image size (Total pixels): 567000
# Maximum pixel value: 255
# Minimum pixel value: 0
# No.of channels: 1

# 2.Identify the automatically added property?
# -The property added by `cv.imread` is the default data type of the pixel values: `uint8`.
# -This means pixel values are stored as 8-bit unsigned integers, ranging from 0 to 255.

# 3.Explanation:
# The `uint8` data type automatically clips pixel values outside the 0-255 range.
# This means any values in the image beyond this range are truncated, potentially altering the original data if it had higher bit depth (e.g., 16-bit images).

####################################
#wapp for notepad
from tkinter import*
from PIL import ImageTk,Image #pillow import from command fromt
from tkinter import StringVar,IntVar,scrolledtext,END,filedialog
from tkinter import messagebox as msg

root=Tk()
root.geometry("600x600")

root.title("Notepad")
root.iconbitmap("notepad2.ico")

root_colour='white'
menu_colour='red'
text_colour='black'
root.config(bg=root_colour)

menu_frame=Frame(root,bg="red")
text_frame=Frame(root,bg="black")
menu_frame.pack()
text_frame.pack()

#functions
def change_font(event):
    if font_shape.get()=='none':
        my_font=((font_styles.get()),(font_size.get()))
    else:
        my_font=((font_styles.get()),(font_size.get()),(font_shape.get()))

#changing text of text box
    textbox.config(font=my_font)

def close_window():
    question=msg.askyesno('close notepad',"Are you sure you want to close the window")
    if question==1:
        root.destroy()

def new_notepad():
    question=msg.askyesno('new note',"Are you sure you want to create a New note")
    if question==1:
        textbox.delete("1.0",END)

def save_file():
    save_name=filedialog.askopenfilenames(initialdir="./",title="save note",filetypes=(("Text files","*.txt"),("All files","*,*")))
    with open(save_name, 'w') as f:
        f.write(textbox.get("1.0",END))

def open_file():
    open_note=filedialog.askopenfilenames(initialdir="./",title="open note",filetypes=(("text files","*.txt"),("all files","*,*")))
    with open(open_note, 'r') as f:
        text=f.read()
        textbox.insert("1.0",text)


new_image=ImageTk.PhotoImage(Image.open('new.ico'))
new_button=Button(menu_frame,image=new_image,command=new_notepad)
new_button.grid(row=0,column=0,padx=5,pady=5)

open_image=ImageTk.PhotoImage(Image.open('open.ico'))
open_button=Button(menu_frame,image=open_image,command=open_file)
open_button.grid(row=0,column=1,padx=5,pady=5)

save_image=ImageTk.PhotoImage(Image.open('save.ico'))
save_button=Button(menu_frame,image=save_image,command=save_file)
save_button.grid(row=0,column=2,padx=5,pady=5)

close_image=ImageTk.PhotoImage(Image.open('close.ico'))
close_button=Button(menu_frame,image=close_image,command=close_window)
close_button.grid(row=0,column=3,padx=5,pady=5)

styles=['Terminal0','Calibri','Arial','Courier','Calibri','cambria','Georgia','Times New Roam','Wingdings']
font_styles=StringVar()
font_styles_drop=OptionMenu(menu_frame,font_styles,*styles,command=change_font) #Optionmenu is an attribute
font_styles_drop.grid(row=0,column=4,padx=5,pady=5)
font_styles.set('Terminal')
font_styles_drop.config(width=12)

size=[12,17,22,24,26,32,36,38,44,48,72 ]
font_size=IntVar()
font_size_drop=OptionMenu(menu_frame,font_size,*size,command=change_font)
font_size_drop.grid(row=0,column=6,padx=5,pady=5)
font_size.set('12')
font_size_drop.config(width=6)

shape=['none','bold','italic','underline']
font_shape=StringVar()
font_shape_drop=OptionMenu(menu_frame,font_shape,*shape,command=change_font)
font_shape_drop.grid(row=0,column=7,padx=5,pady=5)
font_shape.set('none')
font_shape_drop.config(width=5)

my_font=((font_styles.get()),(font_size.get()))


textbox=scrolledtext.ScrolledText(text_frame,width=1000,height=1000,font=my_font)#Scrolled text
textbox.pack()


root.mainloop()

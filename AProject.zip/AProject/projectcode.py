import json  
import pandas as pd  
from pymodbus.client import ModbusTcpClient  
from pymodbus.exceptions import ModbusException  
import time  
import logging  # For logging messages and errors


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
# Configures logging to show time, log level, and message in the console

json_file = r"C:\Users\91833\PycharmProjects\PFACraneSimulation\crane_commands.json"


client = ModbusTcpClient('127.0.0.1')


# Function to read from a specified Modbus register address
def read_input(address):
    try:
        result = client.read_holding_registers(address, 1)
        if result.isError():
            logging.error(f"Error reading from address {address}")
            return None  
        return result.registers[0] 
    except ModbusException as e:
        logging.error(f"ModbusException: {e}")
        return None 
# Function to write a value to a specific Modbus register address
def write_output(address, value):
    try:
        result = client.write_register(address, value)
        if result.isError():
            logging.error(f"Error writing to address {address}")
        else:
            logging.info(f"Successfully wrote {value} to address {address}")
    except ModbusException as e:
        logging.error(f"ModbusException: {e}")

# Function to execute commands from the JSON file
def execute_commands_from_json(json_file):
    try:
        with open(json_file, 'r') as file:
            data = json.load(file) 
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logging.error(f"Failed to load JSON file: {e}")
        return  
    df = pd.DataFrame(data.get('actions', []))
    # Iterate over each action in the DataFrame
    for _, action in df.iterrows():
        # Handle vacuum commands if present 
        if 'vacuum' in action and pd.notna(action['vacuum']):
            vacuum_state = int(action['vacuum'])  
            logging.info(f"Setting vacuum to {'ON' if vacuum_state == 1 else 'OFF'}")
            write_output(3, vacuum_state) 
            time.sleep(0.5)  

        # Handle crane movement commands
        # Check for 'setX'/'setY' OR 'moveTo' format for flexibility
        if ('setX' in action and not pd.isna(action['setX']) and
            'setY' in action and not pd.isna(action['setY'])):
            # Get X and Y positions from the action
            setX, setY = int(action['setX']), int(action['setY'])  
        elif 'moveTo' in action and isinstance(action['moveTo'], dict):
            move_to = action['moveTo']  
            setX, setY = int(move_to.get('x', 0)), int(move_to.get('y', 0))  
        else:
            continue  

        logging.info(f"Moving crane to position X: {setX}, Y: {setY}")
        write_output(1, setX)  
        write_output(2, setY) 
        time.sleep(0.5)  

        # Wait for the crane to reach the target position
        while True:
            posX = read_input(15) 
            posY = read_input(16)  
            logging.info(f"Current crane position - X: {posX}, Y: {posY}")  
            if posX == setX and posY == setY:
                # Log that the target has been reached
                logging.info("Crane has reached the target position.")  
                break  
            time.sleep(0.5)  

    logging.info("Every crane command was successfully carried out.")  

# Main program execution
if __name__ == "__main__":
    try:
        if client.connect():  
            logging.info("Connected to Modbus server.") 
            execute_commands_from_json(json_file)  
        else:
            logging.error("Failed to connect to Modbus server.")  
    finally:
        client.close() 
        logging.info("Modbus connection closed.") 
